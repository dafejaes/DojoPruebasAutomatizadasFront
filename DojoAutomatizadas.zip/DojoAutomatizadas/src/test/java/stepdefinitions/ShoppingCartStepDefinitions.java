package stepdefinitions;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import tasks.AddToCart;
import tasks.LoggeIn;
import tasks.Swaglab;

import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class ShoppingCartStepDefinitions {

    @Managed(driver = "chrome")
    protected WebDriver hisBrowser;

    @Before
    public void InitialSetup(){
        OnStage.setTheStage(new OnlineCast());
        theActorCalled("usuario").can(BrowseTheWeb.with(hisBrowser));
    }

    @Given("^the user opens the browser and goes to the Swag labs page$")
    public void theUserOpensTheBrowserAndGoesToTheSwagLabsPage() {
        theActorInTheSpotlight().wasAbleTo(Swaglab.OpenPage());
    }


    @When("^the user is logged in$")
    public void theUserIsLoggedIn() {
        theActorInTheSpotlight().attemptsTo(LoggeIn.Try());
    }

    @When("^add to cart one item$")
    public void addToCartOneItem() {
        theActorInTheSpotlight().attemptsTo(AddToCart.OneItem());
    }

    @When("^checkout$")
    public void checkout() {

    }

    @When("^confirm the purchase$")
    public void confirmThePurchase() {

    }

    @Then("^the system confirms the order$")
    public void theSystemConfirmsTheOrder() {

    }
}
