package userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class SwagLabMenu {
    public static final Target INPUT_USERNAME = Target.the("Input Username")
            .locatedBy("//input[@id='user-name']");
    public static final Target INPUT_PASSWORD = Target.the("Input Password")
            .locatedBy("//input[@id='password']");
    public static final Target BUTTON_LOGIN = Target.the("Button Login")
            .locatedBy("//input[@id='login-button']");
    public static final Target TITLE_PRODUCTS = Target.the("Title products")
            .locatedBy("//span[text()='Products']");
    public static final Target BUTTON_ADD_TO_CART = Target.the("Button add to cart")
            .locatedBy("//button[@id='add-to-cart-sauce-labs-backpack']");
    public static final Target CART_ACTIVE = Target.the("Cart active")
            .locatedBy("//span[text()='1']");
    public static final Target TITLE_YOUR_CART = Target.the("Title your cart")
            .locatedBy("//span[text()='Your Cart']");
}
