package util;

public class ValuesConstants {
    public static final String USERNAME = "standard_user";
    public static final String PASSWORD = "secret_sauce";
}
