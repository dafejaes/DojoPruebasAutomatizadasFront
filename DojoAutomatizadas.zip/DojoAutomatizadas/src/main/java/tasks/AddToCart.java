package tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import userinterface.SwagLabMenu;

public class AddToCart implements Task {
    public static AddToCart OneItem() {
        return Tasks.instrumented(AddToCart.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SwagLabMenu.BUTTON_ADD_TO_CART),
                WaitUntil.the(SwagLabMenu.CART_ACTIVE, WebElementStateMatchers.isVisible()).forNoMoreThan(10).seconds(),
                Click.on(SwagLabMenu.CART_ACTIVE),
                WaitUntil.the(SwagLabMenu.TITLE_YOUR_CART, WebElementStateMatchers.isVisible()).forNoMoreThan(10).seconds()
        );
    }
}
