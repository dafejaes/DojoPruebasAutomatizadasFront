package tasks;

import com.openhtmltopdf.css.constants.ValueConstants;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import userinterface.SwagLabMenu;
import util.ValuesConstants;

public class LoggeIn implements Task {

    public static LoggeIn Try() {
        return Tasks.instrumented(LoggeIn.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitUntil.the(SwagLabMenu.INPUT_USERNAME, WebElementStateMatchers.isVisible()).forNoMoreThan(10).seconds(),
                Enter.theValue(ValuesConstants.USERNAME).into(SwagLabMenu.INPUT_USERNAME),
                Enter.theValue(ValuesConstants.PASSWORD).into(SwagLabMenu.INPUT_PASSWORD),
                Click.on(SwagLabMenu.BUTTON_LOGIN),
                WaitUntil.the(SwagLabMenu.TITLE_PRODUCTS, WebElementStateMatchers.isVisible()).forNoMoreThan(10).seconds()
        );
    }
}
